import React, { useState, useEffect } from 'react';
import { Menu, X, ExternalLink, Github, Linkedin, Mail, Phone, MapPin, ArrowRight, Award, Briefcase, BookOpen, FolderOpen } from 'lucide-react';

export default function AbhisekPortfolioUpdated() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'story', label: 'My Story' },
    { id: 'experience', label: 'Experience' },
    { id: 'skills', label: 'Skills' },
    { id: 'education', label: 'Education' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'contact', label: 'Contact' }
  ];

  const experiences = [
    {
      role: 'Co-Founder & Business Development Manager',
      company: 'Your-Creator',
      period: '2023 - Present',
      type: 'Self Employed | Remote',
      description: 'Build websites/landing pages, run SEO and Google Business Profile optimization, manage social media, and produce content & video ads for SMEs. Plan content calendars, shoot/edit short-form videos, and coordinate UGC/influencers. Lead sales discovery, scoping, and client communications with actionable reporting.',
      url: 'https://yourcreator.in/'
    },
    {
      role: 'Warranty Specialist',
      company: 'Wickes',
      period: '2025 - 2026',
      type: 'Full Time | United Kingdom',
      description: 'Manage complex customer cases and warranty claims, ensuring commercially sound and customer-focused resolutions. Influence key business decisions relating to refunds, settlements, and service recovery through data-driven analysis. Partner with internal and external stakeholders to improve operational performance and issue resolution outcomes. Identify trends and root causes to support continuous improvement initiatives.'
    },
    {
      role: 'Kitchen Supervisor/Content Strategist',
      company: 'Yumas',
      period: '2023 - 2024',
      type: 'United Kingdom',
      description: 'Led day-to-day operational activities, ensuring smooth service delivery in a high-pressure environment. Improved workflow efficiency through effective planning and problem resolution. Monitored stock, inventory, and supplier requirements. Delivered customer-focused solutions contributing to positive experiences. Assisted with digital marketing and content initiatives supporting brand growth.'
    },
    {
      role: 'Senior Customer Delight Executive',
      company: 'Wakefit',
      period: '2021 - 2023',
      type: 'Full Time | India',
      description: 'Managed end-to-end service delivery operations across pre-sales, sales, and post-sales channels. Leveraged CRM platforms and customer insights to analyze trends and improve resolution performance. Owned escalated customer cases by coordinating with internal teams (logistics, installation, quality, operations). Conducted root cause analysis and identified process improvement opportunities to reduce recurring issues.'
    },
    {
      role: 'Store Manager',
      company: 'Pioneer Power Solutions',
      period: '2019 - 2021',
      type: 'Full Time | India',
      description: 'Led store operations, sales performance, customer experience, and team management in a high-volume retail environment. Drove revenue growth through consultative selling, upselling, and customer engagement strategies. Managed inventory control, merchandising standards, and supplier coordination. Recruited, trained, and developed staff, improving service quality and sales performance.'
    }
  ];

  const skills = [
    {
      category: 'Customer Experience & CRM',
      items: ['Customer Journey Management', 'CRM Platforms', 'Escalation Handling', 'Service Recovery', 'Root Cause Analysis', 'Process Improvement', 'Ombudsman Cases']
    },
    {
      category: 'Digital & Business Systems',
      items: ['Zendesk', 'Zoho CRM', 'SAP', 'Slack', 'AWS', 'SQL', 'SPSS', 'Excel', 'POS Systems', 'E-Commerce Platforms']
    },
    {
      category: 'Sales & Retail Operations',
      items: ['Retail Strategy', 'Upselling & Cross-Selling', 'Inventory Management', 'KPI Management', 'Team Leadership', 'Staff Training', 'Customer Retention']
    },
    {
      category: 'Digital Marketing & Content',
      items: ['Social Media (Instagram, TikTok)', 'Video Editing', 'Copywriting', 'Email Campaigns', 'Local SEO', 'Google Business Profile', 'Landing Pages', 'Brand Storytelling']
    }
  ];

  const certifications = [
    {
      title: 'Master of Business Administration (MBA)',
      issuer: 'University of Northampton, UK',
      year: '2024',
      specialization: 'CRM, Customer Experience & Service Delivery'
    },
    {
      title: 'Bachelor of Business Administration',
      issuer: 'Trident Academy of Creative Technology, India',
      year: '2022'
    },
    {
      title: 'SPSS Training Certification',
      issuer: 'IBM',
      year: '2024'
    }
  ];

  const portfolioItems = [
    {
      title: 'Your-Creator',
      description: 'Digital growth agency helping SMEs build their brand presence through strategic web solutions, SEO optimization, and content creation.',
      highlights: ['Website Development', 'SEO Optimization', 'Social Media Management', 'Content Production'],
      link: 'https://yourcreator.in/',
      icon: '🌐'
    },
    {
      title: 'Copywriting & Content Portfolio',
      description: 'Professional copywriting samples including email campaigns, social media content, landing page copy, and brand storytelling materials.',
      highlights: ['Email Campaigns', 'Social Content', 'Landing Pages', 'Brand Storytelling', 'Customer Engagement Copy'],
      link: 'https://drive.google.com/drive/folders/1bFfSEBuQCA6_5LJctsQDDctxWdn8pVk5?usp=drive_link',
      icon: '📝'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute top-0 -left-40 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-blue-500/5 rounded-full blur-3xl animate-pulse" style={{animationDelay: '2s'}}></div>
      </div>

      {/* Navigation */}
      <nav className={`fixed w-full top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-slate-950/95 backdrop-blur shadow-lg' : 'bg-transparent'}`}>
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-500 bg-clip-text text-transparent">Abhisek Ray</h1>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex gap-8">
              {navItems.map(item => (
                <a key={item.id} href={`#${item.id}`} className="text-sm font-medium hover:text-indigo-400 transition-colors">
                  {item.label}
                </a>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden">
              {menuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {menuOpen && (
            <div className="md:hidden pb-4 space-y-2">
              {navItems.map(item => (
                <a key={item.id} href={`#${item.id}`} onClick={() => setMenuOpen(false)} className="block px-4 py-2 hover:bg-slate-700 rounded transition-colors">
                  {item.label}
                </a>
              ))}
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-20">
        <div className="text-center space-y-6 max-w-3xl mx-auto animate-in fade-in duration-1000">
          <div className="space-y-2">
            <h2 className="text-6xl md:text-7xl font-bold leading-tight">
              <span className="bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-600 bg-clip-text text-transparent">
                CRM & Customer Experience
              </span>
            </h2>
            <h2 className="text-5xl md:text-6xl font-bold text-slate-300">
              Specialist
            </h2>
          </div>
          <p className="text-xl md:text-2xl text-slate-300">Driving Growth Through Data-Driven Customer Solutions</p>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">
            MBA specializing in CRM, customer experience, and service delivery. Helping organizations scale through strategic customer-centric solutions and digital innovation.
          </p>
          <div className="flex gap-4 justify-center pt-8 flex-wrap">
            <a href="#story" className="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-lg font-semibold transition-colors flex items-center gap-2 mx-auto">
              Read My Story <ArrowRight size={20} />
            </a>
            <a href="#contact" className="px-8 py-3 border border-indigo-500 hover:bg-indigo-500/10 rounded-lg font-semibold transition-colors mx-auto">
              Get In Touch
            </a>
          </div>
          <div className="flex gap-4 justify-center pt-4 flex-wrap text-sm text-slate-400">
            <div className="flex items-center gap-2">
              <MapPin size={18} /> Northampton, UK
            </div>
            <div className="flex items-center gap-2">
              <Phone size={18} /> +44 (0) 07437331591
            </div>
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section id="story" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-5xl font-bold mb-12 text-center">From Retail to CRM Excellence</h3>
          <div className="space-y-6 text-slate-300 text-lg leading-relaxed">
            <p>
              I didn't start in a corporate boardroom. I started in retail—learning the fundamentals of customer service, operations, and what it truly means to deliver excellence. That foundation shaped everything.
            </p>
            <p>
              As a <span className="text-indigo-400 font-semibold">Store Manager at Pioneer Power Solutions</span>, I discovered the power of customer engagement and strategic thinking. Managing operations, driving revenue through consultative selling, and training teams taught me that success is built on relationships and understanding people.
            </p>
            <p>
              Then came my pivot into <span className="text-indigo-400 font-semibold">customer experience at Wakefit</span>, where I managed the entire service delivery lifecycle. I didn't just resolve tickets—I reimagined processes using CRM platforms and data-driven insights. I coordinated cross-functional teams, conducted root cause analysis, and helped achieve significant improvements in customer satisfaction. That's when I realized my true passion: <span className="text-purple-400 font-semibold">turning insight into action through CRM excellence</span>.
            </p>
            <p>
              Today, as <span className="text-indigo-400 font-semibold">Co-Founder & Business Development Manager at Your-Creator</span>, I'm helping SMEs grow through strategic digital solutions—websites, SEO, content creation, and brand storytelling. Combined with my <span className="text-purple-400 font-semibold">MBA from University of Northampton</span> specializing in CRM and customer experience, I blend data-driven strategy with practical execution.
            </p>
            <p className="text-center text-purple-300 text-xl font-semibold mt-8">
              "Great customer experiences aren't accidents—they're the result of strategic thinking, data analysis, and relentless execution."
            </p>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4 bg-slate-800/50">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-4xl font-bold mb-12">Professional Experience</h3>
          <div className="space-y-8">
            {experiences.map((exp, idx) => (
              <div key={idx} className="border-l-2 border-indigo-500 pl-6 pb-8 relative hover:border-purple-500 transition-colors">
                <div className="absolute -left-3 w-4 h-4 bg-indigo-500 rounded-full"></div>
                <div className="flex items-start justify-between flex-wrap gap-2">
                  <div>
                    <h4 className="text-2xl font-bold text-indigo-400">{exp.role}</h4>
                    <p className="text-purple-400 font-semibold">{exp.company}</p>
                    <p className="text-slate-400 text-sm">{exp.type}</p>
                  </div>
                  <span className="text-slate-500 text-sm whitespace-nowrap">{exp.period}</span>
                </div>
                <p className="text-slate-300 mt-3">{exp.description}</p>
                {exp.url && (
                  <a href={exp.url} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-purple-400 text-sm font-semibold mt-2 flex items-center gap-1">
                    Visit Website <ExternalLink size={14} />
                  </a>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-4xl font-bold mb-12">Technical Skills & Expertise</h3>
          <div className="grid md:grid-cols-2 gap-8">
            {skills.map((skillGroup, idx) => (
              <div key={idx} className="bg-slate-700/30 backdrop-blur border border-slate-600 rounded-lg p-6 hover:border-indigo-500 transition-colors">
                <h4 className="text-lg font-bold text-indigo-400 mb-4 flex items-center gap-2">
                  <Briefcase size={20} /> {skillGroup.category}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {skillGroup.items.map((skill, i) => (
                    <span key={i} className="px-3 py-1 bg-indigo-500/20 border border-indigo-500/50 rounded-full text-sm text-indigo-300 hover:bg-indigo-500/30 transition-colors">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 px-4 bg-slate-800/50">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-4xl font-bold mb-8 flex items-center gap-2">
            <BookOpen size={32} /> Education & Certifications
          </h3>
          <div className="space-y-4">
            {certifications.map((cert, idx) => (
              <div key={idx} className="bg-slate-700/30 backdrop-blur border border-slate-600 rounded-lg p-6 hover:border-indigo-500 transition-colors">
                <h4 className="text-2xl font-bold text-indigo-400">{cert.title}</h4>
                <p className="text-slate-400">{cert.issuer}</p>
                {cert.specialization && (
                  <p className="text-purple-400 text-sm font-semibold mt-1">Specialization: {cert.specialization}</p>
                )}
                <p className="text-slate-500 text-sm mt-2">Completed: {cert.year}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h3 className="text-4xl font-bold mb-12 flex items-center gap-2">
            <FolderOpen size={32} /> Portfolio & Work Samples
          </h3>
          <div className="grid md:grid-cols-2 gap-6">
            {portfolioItems.map((item, idx) => (
              <div key={idx} className="bg-slate-700/30 backdrop-blur border border-slate-600 rounded-lg p-6 hover:border-indigo-500 transition-colors">
                <div className="text-4xl mb-3">{item.icon}</div>
                <h4 className="text-2xl font-bold text-indigo-400 mb-2">{item.title}</h4>
                <p className="text-slate-300 mb-4">{item.description}</p>
                <div className="space-y-2 mb-4">
                  {item.highlights.map((highlight, i) => (
                    <div key={i} className="flex items-center gap-2 text-slate-400">
                      <span className="text-purple-400">✓</span> {highlight}
                    </div>
                  ))}
                </div>
                <a href={item.link} target="_blank" rel="noopener noreferrer" className="text-indigo-400 hover:text-purple-400 font-semibold flex items-center gap-2 mt-4">
                  View {item.title === 'Your-Creator' ? 'Website' : 'Portfolio'} <ExternalLink size={16} />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 bg-slate-800/50">
        <div className="max-w-4xl mx-auto text-center space-y-8">
          <h3 className="text-4xl font-bold">Let's Connect & Collaborate</h3>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            I'm always interested in discussing CRM strategies, customer experience excellence, digital growth, and brand building opportunities. Let's create something great together.
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <a href="mailto:thankgodabhisekray2002@gmail.com" className="flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-lg font-semibold transition-colors">
              <Mail size={20} /> Email Me
            </a>
            <a href="tel:+447437331591" className="flex items-center gap-2 px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold transition-colors">
              <Phone size={20} /> Call Me
            </a>
            <a href="https://linkedin.com/in/abhisekray" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold transition-colors">
              <Linkedin size={20} /> LinkedIn
            </a>
            <a href="https://yourcreator.in" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-semibold transition-colors">
              <ExternalLink size={20} /> Your-Creator
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 py-8 px-4 text-center text-slate-400">
        <p>© 2024 Abhisek Ray. All rights reserved. | Made with ❤️ | Hosted on GitHub Pages</p>
      </footer>
    </div>
  );
}
